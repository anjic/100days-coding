define({
  "name": "X-IO Monitor ",
  "version": "0.0.1",
  "description": "apiDoc for X-IO API",
  "title": "X-IO ReST",
  "url": "https://<ip-address>/api",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-12-07T11:18:03.699Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
