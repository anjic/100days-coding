from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework_jwt.views import obtain_jwt_token
from api.views.users import (UsersList, UserDetails, Login, UserPassword)
"""
@apiGroup User
@apiName GetUsersList
@api {get} /sangroup/ Display List of Users

@apiSuccess {Integer} id Unique UserID.
@apiSuccess {String} first_name Firstname of the User(optional)
@apiSuccess {String} last_name  Lastname of the User(optional)
@apiSuccess {String} email      Email of the User
@apiSuccess {Boolean} is_active Whether User is active or not(optional)
@apiSuccess {Boolean} is_staff  Whether User is admin or not(optional)
@apiSuccess {Integer} groups  GroupID
@apiSuccess {String} group_name group name in which the user belongs.

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "result": "success",
    "response": {
        "data": [
            {
                "id": 1,
                "first_name": "MSys",
                "last_name": "Technologies",
                "username": "msys",
                "email": "msys@example.com",
                "is_active": true,
                "is_staff": true,
                "groups": [
                    1
                ],
                "group_name": [
                    "X-IO"
                ]
            },
            {
                "id": 7,
                "first_name": "Test",
                "last_name": "MSys",
                "username": "test",
                "email": test@gmail.com",
                "is_active": true,
                "is_staff": true,
                "groups": [
                    1
                ],
                "group_name": [
                    "X-IO"
                ]
            }
        ]
    }
}

"""

"""
@apiGroup User
@apiName CreateUser
@api {post} /user/ Create New User


@apiParam {String} username     Optional Username of the User
@apiParam {String} [firstname]  Optional Firstname of the User
@apiParam {String} [lastname]   Optional Lastname of the User
@apiParam {String} email        Mandatory Email of the User
@apiParam {String} password     Mandatory password of the User
@apiParam {Boolean} [is_active] Optional active status to check whether user is active or not
@apiParam {Boolean} [is_staff]  Optional to assign Whether User is admin or not

@apiSuccess {Integer} id        Unique UserID.
@apiSuccess {String} username   Username of the User(optional)
@apiSuccess {String} first_name Firstname of the User(optional)
@apiSuccess {String} last_name  Lastname of the User(optional)
@apiSuccess {String} email      Email of the User
@apiSuccess {String} password   password of the User
@apiSuccess {Boolean} is_active Whether User is active or not(optional)
@apiSuccess {Boolean} is_staff  Whether User is admin or not(optional)
@apiSuccess {Integer} groups  GroupID
@apiSuccess {String} group_name group name in which the user belongs

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "result": "success",
    "response": {
        "data": [
            {
                "id": 1,
                "first_name": "MSys",
                "last_name": "Technologies",
                "username": "msys",
                "email": "msys@example.com",
                "is_active": true,
                "is_staff": true,
                "groups": [
                    1
                ],
                "group_name": [
                    "X-IO"
                ]
            }
}

@apiError BadRequest Duplicate entry 'name' for key 'username'
@apiErrorExample {json} Error-Response:
    HTTP/1.1 400 Bad Request
        {
        "result":"fail",
        "response":
                  {
                  "data":"(1062, \"Duplicate entry 'name' for key 'username'\")"
                  }
        }

"""
"""
@apiGroup User
@apiName UpdateUser
@api {put} /user/id/ Update UserDetails

@apiParam {String} [firstname]  Optional Firstname of the User
@apiParam {String} [lastname]   Optional Lastname of the User
@apiParam {String} email        Mandatory Email of the User
@apiParam {String} password     Mandatory password of the User
@apiParam {Boolean} [is_active] Optional active status to check whether user is active or not
@apiParam {Boolean} [is_staff]  Optional to assign Whether User is admin or not

@apiSuccess {Integer} id Unique UserID
@apiSuccess {String} first_name Firstname of the User(optional)
@apiSuccess {String} last_name  Lastname of the User(optional)
@apiSuccess {String} email      Email of the User
@apiSuccess {Boolean} is_active Whether User is active or not(optional)
@apiSuccess {Boolean} is_staff  Whether User is admin or not(optional)
@apiSuccess {Integer} groups  GroupID

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "result": "success",
    "response": {
        "data": [
            {
                "id": 1,
                "first_name": "MSys",
                "last_name": "Technologies",
                "username": "msys",
                "email": "msys@example.com",
                "is_active": true,
                "is_staff": true,
                "groups": [
                    1
                ],
                "group_name": [
                    "X-IO"
                ]
            }
}

@apiError BadRequest Duplicate entry 'name' for key 'username'
@apiErrorExample {json} Error-Response:
    HTTP/1.1 400 Bad Request
        {
        "result":"fail",
        "response":
                  {
                  "data":"(1062, \"Duplicate entry 'name' for key 'username'\")"
                  }
        }

"""
"""
@apiGroup User
@apiName DeleteUser
@api {delete} /user/id/ Delete UserDetails

@apiParam {Integer} id Unique UserID

@apiSuccess {Integer} id Unique UserID

@apiSuccessExample Success-Response:
    HTTP 204 No Content
"""
urlpatterns = [
    # url(r'^login/$', obtain_jwt_token),
    url(r'^login/$', Login.as_view()),
    url(r'^user/(?P<id>[\w\-]+)/$', UserDetails.as_view()),
    url(r'^user/$', UsersList.as_view()),
    url(r'^user-password/$', UserPassword.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
