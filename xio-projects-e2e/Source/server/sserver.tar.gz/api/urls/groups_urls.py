from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns
from api.views.groups import (GroupList, GroupDetails, PermissionList)
"""
@apiGroup Groups
@apiName GetGroupList
@api {get} /group/ Display List of Group

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for displaying list of groups.
@apiSuccess {String} message It gives success or error message.
@apiSuccess {String} error It contains error messages.

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "message": "success",
    "time_taken": {
        "python": "0.01s",
        "req_recv_time": "1504377210",
        "total": "0.01s",
        "cortex": "0.0s",
        "res_send_time": "1504377210"
    },
    "result": {
        "status_code": 200,
        "response": {
            "data": [
                {
                    "id": 1,
                    "name": "Administrators",
                    "permissions": [],
                    "sudo_group": true
                },
                {
                    "id": 2,
                    "name": "msys",
                    "permissions": [],
                    "sudo_group": false
                }
            ]
        },
        "error": false
    }
}
"""
"""
@apiGroup Groups
@apiName CreateUserGroup

@api {post} /group/ Create User Group
@apiParam {String} name Name of the Group

@apiParamExample {json} Input.
{
    "name":"test"
}
@apiSuccessExample Success-Response:
HTTP/1.1 201 Created
{
    "message": "success",
    "time_taken": {
        "python": "",
        "req_recv_time": "",
        "total": "",
        "cortex": "",
        "res_send_time": ""
    },
    "result": {
        "status_code": 201,
        "response": {
            "data": "New Group created Succesfully"
        },
        "error": false
    }
}
@apiErrorExample Error-Response:
HTTP/1.1 400 Bad Request
{
    "message": "fail",
    "time_taken": {
        "python": "",
        "req_recv_time": "",
        "total": "",
        "cortex": "",
        "res_send_time": ""
    },
    "result": {
        "status_code": 400,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 400,
            "message": "(1048, \"Column 'name' cannot be null\")"
        }
    }
}
"""
"""
@apiGroup Groups
@apiName GetGroupDetail
@api {get} /group/<group-id> Get Particular Group Detail

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for displaying particular group.
@apiSuccess {String} message It gives success or error message.
@apiSuccess {String} error It contains error messages.

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "message": "success",
    "time_taken": {
        "python": "0.00s",
        "req_recv_time": "1504378925",
        "total": "0.00s",
        "cortex": "0.0s",
        "res_send_time": "1504378925"
    },
    "result": {
        "status_code": 200,
        "response": {
            "data": {
                "id": 1,
                "name": "Administrators",
                "permissions": []
            }
        },
        "error": false
    }
}
@apiErrorExample Error-Response:
HTTP/1.1 404 Not Found
{
    "message": "fail",
    "time_taken": {
        "python": "0.01s",
        "req_recv_time": "1504379313",
        "total": "0.01s",
        "cortex": "0.0s",
        "res_send_time": "1504379313"
    },
    "result": {
        "status_code": 404,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 404,
            "message": "Group Not Found"
        }
    }
}
"""
"""
@apiGroup Groups
@apiName UpdateGroupDetails

@api {put} /group/<group-id> Update Particular Group Detail
@apiParam {String} name Name of the Group

@apiParamExample {json} Input.
{
    "name":"test"
}

@apiErrorExample Error-Response:
HTTP/1.1 404 Not Found
{
   "message":"fail",
   "time_taken":{
      "python":"",
      "req_recv_time":"",
      "total":"",
      "cortex":"",
      "res_send_time":""
   },
   "result":{
      "status_code":400,
      "response":{
         "data":[

         ]
      },
      "error":{
         "status_code":400,
         "message":{
            "name":[
               "Group with this name already exists."
            ]
         }
      }
   }
}
"""
"""
@apiGroup Groups
@apiName DeleteGroup
@api {delete} /group/<group-id> Delete Particular Group Detail

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for deleting particular group.
@apiSuccess {String} message It gives success or error message.
@apiSuccess {String} error It contains error messages.

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "message": "success",
    "time_taken": {
        "python": "0.00s",
        "req_recv_time": "1504378925",
        "total": "0.00s",
        "cortex": "0.0s",
        "res_send_time": "1504378925"
    },
    "result": {
        "status_code": 200,
        "response": {
            "data": {
                "id": 1,
                "name": "Administrators",
                "permissions": []
            }
        },
        "error": false
    }
}
@apiErrorExample Error-Response:
HTTP/1.1 400 Bad Request
{
    "message": "fail",
    "time_taken": {
        "python": "0.01s",
        "req_recv_time": "1504379313",
        "total": "0.01s",
        "cortex": "0.0s",
        "res_send_time": "1504379313"
    },
    "result": {
        "status_code": 400,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 400,
            "message": "dministrator group cannot be deleted"
        }
    }
}
"""

"""
@apiGroup Groups
@apiName GetUserPermissionList
@api {get} /permission/ Display List of Permission

@apiSuccess {String} result Displays the result
@apiSuccess {Integer} response It gives response as status code
@apiSuccess {String} data  It contains attributes of the Permission

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{     
    "result": "success",
    "response": {
        "data": [
            {
                "id": 1,
                "name": "Can add log entry",
                "codename": "add_logentry",
                "content_type": 1
            },
            {
                "id": 2,
                "name": "Can change log entry",
                "codename": "change_logentry",
                "content_type": 1
            },
            {
                "id": 3,
                "name": "Can delete log entry",
                "codename": "delete_logentry",
                "content_type": 1
            },
            {
                "id": 55,
                "name": "Can add array capability",
                "codename": "add_arraycapability",
                "content_type": 19
            },
            {
                "id": 56,
                "name": "Can change array capability",
                "codename": "change_arraycapability",
                "content_type": 19
            },
            {
                "id": 57,
                "name": "Can delete array capability",
                "codename": "delete_arraycapability",
                "content_type": 19
            },
            {
                "id": 61,
                "name": "Can add array chronometer",
                "codename": "add_arraychronometer",
                "content_type": 21
            },
            {
                "id": 62,
                "name": "Can change array chronometer",
                "codename": "change_arraychronometer",
                "content_type": 21
            },
            {
                "id": 63,
                "name": "Can delete array chronometer",
                "codename": "delete_arraychronometer",
                "content_type": 21
            },
            {
                "id": 49,
                "name": "Can add array controller",
                "codename": "add_arraycontroller",
                "content_type": 17
            },
            {
                "id": 50,
                "name": "Can change array controller",
                "codename": "change_arraycontroller",
                "content_type": 17
            },
            {
                "id": 51,
                "name": "Can delete array controller",
                "codename": "delete_arraycontroller",
                "content_type": 17
            },
            {
                "id": 46,
                "name": "Can add arrays",
                "codename": "add_arrays",
                "content_type": 16
            },
            {
                "id": 47,
                "name": "Can change arrays",
                "codename": "change_arrays",
                "content_type": 16
            },
            {
                "id": 48,
                "name": "Can delete arrays",
                "codename": "delete_arrays",
                "content_type": 16
            },
            {
                "id": 58,
                "name": "Can add capability attribute",
                "codename": "add_capabilityattribute",
                "content_type": 20
            },
            {
                "id": 59,
                "name": "Can change capability attribute",
                "codename": "change_capabilityattribute",
                "content_type": 20
            },
            {
                "id": 60,
                "name": "Can delete capability attribute",
                "codename": "delete_capabilityattribute",
                "content_type": 20
            },
            {
                "id": 64,
                "name": "Can add chronometer attribute",
                "codename": "add_chronometerattribute",
                "content_type": 22
            },
            {
                "id": 65,
                "name": "Can change chronometer attribute",
                "codename": "change_chronometerattribute",
                "content_type": 22
            },
            {
                "id": 66,
                "name": "Can delete chronometer attribute",
                "codename": "delete_chronometerattribute",
                "content_type": 22
            },
            {
                "id": 52,
                "name": "Can add controller attribute",
                "codename": "add_controllerattribute",
                "content_type": 18
            },
            {
                "id": 53,
                "name": "Can change controller attribute",
                "codename": "change_controllerattribute",
                "content_type": 18
            },
            {
                "id": 54,
                "name": "Can delete controller attribute",
                "codename": "delete_controllerattribute",
                "content_type": 18
            },
            {
                "id": 40,
                "name": "Can add event logs",
                "codename": "add_eventlogs",
                "content_type": 14
            },
            {
                "id": 41,
                "name": "Can change event logs",
                "codename": "change_eventlogs",
                "content_type": 14
            },
            {
                "id": 42,
                "name": "Can delete event logs",
                "codename": "delete_eventlogs",
                "content_type": 14
            },
            {
                "id": 19,
                "name": "Can add ise service",
                "codename": "add_iseservice",
                "content_type": 7
            },
            {
                "id": 20,
                "name": "Can change ise service",
                "codename": "change_iseservice",
                "content_type": 7
            },
            {
                "id": 21,
                "name": "Can delete ise service",
                "codename": "delete_iseservice",
                "content_type": 7
            },
            {
                "id": 28,
                "name": "Can add list ise",
                "codename": "add_listise",
                "content_type": 10
            },
            {
                "id": 29,
                "name": "Can change list ise",
                "codename": "change_listise",
                "content_type": 10
            },
            {
                "id": 30,
                "name": "Can delete list ise",
                "codename": "delete_listise",
                "content_type": 10
            },
            {
                "id": 43,
                "name": "Can add mail user",
                "codename": "add_mailuser",
                "content_type": 15
            },
            {
                "id": 44,
                "name": "Can change mail user",
                "codename": "change_mailuser",
                "content_type": 15
            },
            {
                "id": 45,
                "name": "Can delete mail user",
                "codename": "delete_mailuser",
                "content_type": 15
            },
            {
                "id": 37,
                "name": "Can add mgmt logs",
                "codename": "add_mgmtlogs",
                "content_type": 13
            },
            {
                "id": 38,
                "name": "Can change mgmt logs",
                "codename": "change_mgmtlogs",
                "content_type": 13
            },
            {
                "id": 39,
                "name": "Can delete mgmt logs",
                "codename": "delete_mgmtlogs",
                "content_type": 13
            },
            {
                "id": 22,
                "name": "Can add san group",
                "codename": "add_sangroup",
                "content_type": 8
            },
            {
                "id": 23,
                "name": "Can change san group",
                "codename": "change_sangroup",
                "content_type": 8
            },
            {
                "id": 24,
                "name": "Can delete san group",
                "codename": "delete_sangroup",
                "content_type": 8
            },
            {
                "id": 31,
                "name": "Can add sangroup ise",
                "codename": "add_sangroupise",
                "content_type": 11
            },
            {
                "id": 32,
                "name": "Can change sangroup ise",
                "codename": "change_sangroupise",
                "content_type": 11
            },
            {
                "id": 33,
                "name": "Can delete sangroup ise",
                "codename": "delete_sangroupise",
                "content_type": 11
            },
            {
                "id": 25,
                "name": "Can add san ise",
                "codename": "add_sanise",
                "content_type": 9
            },
            {
                "id": 26,
                "name": "Can change san ise",
                "codename": "change_sanise",
                "content_type": 9
            },
            {
                "id": 27,
                "name": "Can delete san ise",
                "codename": "delete_sanise",
                "content_type": 9
            },
            {
                "id": 34,
                "name": "Can add storage count",
                "codename": "add_storagecount",
                "content_type": 12
            },
            {
                "id": 35,
                "name": "Can change storage count",
                "codename": "change_storagecount",
                "content_type": 12
            },
            {
                "id": 36,
                "name": "Can delete storage count",
                "codename": "delete_storagecount",
                "content_type": 12
            },
            {
                "id": 7,
                "name": "Can add group",
                "codename": "add_group",
                "content_type": 3
            },
            {
                "id": 8,
                "name": "Can change group",
                "codename": "change_group",
                "content_type": 3
            },
            {
                "id": 9,
                "name": "Can delete group",
                "codename": "delete_group",
                "content_type": 3
            },
            {
                "id": 4,
                "name": "Can add permission",
                "codename": "add_permission",
                "content_type": 2
            },
            {
                "id": 5,
                "name": "Can change permission",
                "codename": "change_permission",
                "content_type": 2
            },
            {
                "id": 6,
                "name": "Can delete permission",
                "codename": "delete_permission",
                "content_type": 2
            },
            {
                "id": 10,
                "name": "Can add user",
                "codename": "add_user",
                "content_type": 4
            },
            {
                "id": 11,
                "name": "Can change user",
                "codename": "change_user",
                "content_type": 4
            },
            {
                "id": 12,
                "name": "Can delete user",
                "codename": "delete_user",
                "content_type": 4
            },
            {
                "id": 13,
                "name": "Can add content type",
                "codename": "add_contenttype",
                "content_type": 5
            },
            {
                "id": 14,
                "name": "Can change content type",
                "codename": "change_contenttype",
                "content_type": 5
            },
            {
                "id": 15,
                "name": "Can delete content type",
                "codename": "delete_contenttype",
                "content_type": 5
            },
            {
                "id": 67,
                "name": "Can add cors model",
                "codename": "add_corsmodel",
                "content_type": 23
            },
            {
                "id": 68,
                "name": "Can change cors model",
                "codename": "change_corsmodel",
                "content_type": 23
            },
            {
                "id": 69,
                "name": "Can delete cors model",
                "codename": "delete_corsmodel",
                "content_type": 23
            },
            {
                "id": 16,
                "name": "Can add session",
                "codename": "add_session",
                "content_type": 6
            },
            {
                "id": 17,
                "name": "Can change session",
                "codename": "change_session",
                "content_type": 6
            },
            {
                "id": 18,
                "name": "Can delete session",
                "codename": "delete_session",
                "content_type": 6
            }
        ]
    }
}
"""
urlpatterns = [
    url(r'^group/(?P<id>[\w\-]+)/$', GroupDetails.as_view()),
    url(r'^group/$', GroupList.as_view()),
    url(r'^permission/$', PermissionList.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
