from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns
from api.views.pool_views import(PoolsList, PoolsDetail, PoolsChart, DataReduction)

"""
@apiGroup Pools
@apiName GetPoolsList
@api {get} /ise/<ise-id>/pools/ Display Pools List
@apiParam {Integer} ise-id unique ISE ID.

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for List of Pools.
@apiSuccess {String} message It gives success or error message of the List of Pools.
@apiSuccess {String} error It contains error message .

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "message": "success",
    "time_taken": {
        "python": "0.01s",
        "req_recv_time": "1504445330",
        "total": "1.15s",
        "cortex": "1.14s",
        "res_send_time": "1504445331"
    },
    "result": {
        "status_code": 200,
        "response": {
            "data": {
                "pools": {
                    "_attr": {
                        "self": "https://10.20.238.9/storage/pools"
                    },
                    "pool": {
                        "available": {
                            "_attr": {
                                "total": "12636"
                            },
                            "byredundancy": {
                                "raid-1": 6318,
                                "raid-0": 12636,
                                "raid-5": 10109
                            }
                        },
                        "Flashquota": 0,
                        "id": 1,
                        "size": 14014,
                        "DedupProvisioned": {
                            "SystemData": 687,
                            "UserData": 640
                        },
                        "media": {
                            "media": [
                                {
                                    "tier": {
                                        "tier": "",
                                        "_attr": {
                                            "string": "Flash",
                                            "value": "5"
                                        }
                                    },
                                    "_attr": {
                                        "self": "http://10.20.238.9/storage/arrays/USE26000368OW028/media/1"
                                    },
                                    "health": 125
                                },
                                {
                                    "tier": {
                                        "tier": "",
                                        "_attr": {
                                            "string": "Flash",
                                            "value": "5"
                                        }
                                    },
                                    "_attr": {
                                        "self": "http://10.20.238.9/storage/arrays/USE26000368OW028/media/2"
                                    },
                                    "health": 125
                                }
                            ],
                            "_attr": {
                                "self": "http://10.20.238.9/storage/arrays/USE26000368OW028/media"
                            }
                        },
                        "Flashavailable": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 0
                            }
                        },
                        "ThinThreshold": 75,
                        "status": {
                            "_attr": {
                                "string": "Operational",
                                "value": "0"
                            },
                            "details": {
                                "_attr": {
                                    "value": "0x00000000"
                                },
                                "detail": "None"
                            }
                        },
                        "used": {
                            "_attr": {
                                "total": "1378"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 625
                            }
                        },
                        "globalid": "6001F933001100000000000100000000",
                        "Flashcapacity": 0,
                        "Flashprovisioned": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 0
                            }
                        },
                        "FastSheettotal": 0,
                        "Flashused": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 0
                            }
                        },
                        "provisioned": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 625
                            }
                        },
                        "name": "Pool 1",
                        "DedupUsed": {
                            "SystemData": 687,
                            "UserData": 12
                        },
                        "SlowSheettotal": 59796,
                        "_attr": {
                            "self": "https://10.20.238.9/storage/pools/6001F933001100000000000100000000"
                        },
                        "FastSheetallocated": 0,
                        "volumes": {
                            "_attr": {
                                "self": "https://10.20.238.9/storage/volumes"
                            },
                            "volumes": ""
                        },
                        "SlowSheetallocated": 5881
                    }
                }
            }
        },
        "error": false
    }
}
@apiErrorExample Error-Response:
HTTP/1.1 404 Not Found
{
    "message": "fail",
    "time_taken": {
        "python": "",
        "req_recv_time": "",
        "total": "",
        "cortex": "",
        "res_send_time": ""
    },
    "result": {
        "status_code": 404,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 404,
            "message": "ISE Not Found"
        }
    }
}
"""
"""
@apiGroup Pools
@apiName CreatePool
@api {post} /ise/<ise-id>/pools/ Create Pool
@apiParam {Integer} ise-id unique ISE ID.

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for creating pool.
@apiSuccess {String} message It gives success or error message of the Creating pool.
@apiSuccess {String} error It contains error message .

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
"""
"""
@apiGroup Pools
@apiName DisplayParticularPool
@api {get} /ise/<ise-id>/pools/<pool-id> Get Particular Pool
@apiParam {Integer} ise-id unique ISE ID.
@apiParam {Integer} pool-id unique Pool ID.

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for displaying particular pool info.
@apiSuccess {String} message It gives success or error message.
@apiSuccess {String} error It contains error message .

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "message": "success",
    "time_taken": {
        "python": "0.00s",
        "req_recv_time": "1504445682",
        "total": "1.15s",
        "cortex": "1.14s",
        "res_send_time": "1504445684"
    },
    "result": {
        "status_code": 200,
        "response": {
            "data": {
                "pools": {
                    "_attr": {
                        "self": "https://10.20.238.9/storage/pools"
                    },
                    "pool": {
                        "available": {
                            "_attr": {
                                "total": "12636"
                            },
                            "byredundancy": {
                                "raid-1": 6318,
                                "raid-0": 12636,
                                "raid-5": 10109
                            }
                        },
                        "Flashquota": 0,
                        "id": 1,
                        "size": 14014,
                        "DedupProvisioned": {
                            "SystemData": 687,
                            "UserData": 640
                        },
                        "media": {
                            "media": [
                                {
                                    "tier": {
                                        "tier": "",
                                        "_attr": {
                                            "string": "Flash",
                                            "value": "5"
                                        }
                                    },
                                    "_attr": {
                                        "self": "http://10.20.238.9/storage/arrays/USE26000368OW028/media/1"
                                    },
                                    "health": 125
                                },
                                {
                                    "tier": {
                                        "tier": "",
                                        "_attr": {
                                            "string": "Flash",
                                            "value": "5"
                                        }
                                    },
                                    "_attr": {
                                        "self": "http://10.20.238.9/storage/arrays/USE26000368OW028/media/2"
                                    },
                                    "health": 125
                                }
                            ],
                            "_attr": {
                                "self": "http://10.20.238.9/storage/arrays/USE26000368OW028/media"
                            }
                        },
                        "Flashavailable": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 0
                            }
                        },
                        "ThinThreshold": 75,
                        "status": {
                            "_attr": {
                                "string": "Operational",
                                "value": "0"
                            },
                            "details": {
                                "_attr": {
                                    "value": "0x00000000"
                                },
                                "detail": "None"
                            }
                        },
                        "used": {
                            "_attr": {
                                "total": "1378"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 625
                            }
                        },
                        "globalid": "6001F933001100000000000100000000",
                        "Flashcapacity": 0,
                        "Flashprovisioned": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 0
                            }
                        },
                        "FastSheettotal": 0,
                        "Flashused": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 0
                            }
                        },
                        "provisioned": {
                            "_attr": {
                                "total": "0"
                            },
                            "byredundancy": {
                                "raid-1": 0,
                                "raid-0": 0,
                                "raid-5": 625
                            }
                        },
                        "name": "Pool 1",
                        "DedupUsed": {
                            "SystemData": 687,
                            "UserData": 12
                        },
                        "SlowSheettotal": 59796,
                        "_attr": {
                            "self": "https://10.20.238.9/storage/pools/6001F933001100000000000100000000"
                        },
                        "FastSheetallocated": 0,
                        "volumes": {
                            "_attr": {
                                "self": "https://10.20.238.9/storage/volumes"
                            },
                            "volumes": ""
                        },
                        "SlowSheetallocated": 5881
                    }
                }
            }
        },
        "error": false
    }
}
@apiErrorExample Error-Response:
HTTP/1.1 404 Not Found
{
    "message": "fail",
    "time_taken": {
        "python": "0.00s",
        "req_recv_time": "1504446029",
        "total": "3.85s",
        "cortex": "3.84s",
        "res_send_time": "1504446033"
    },
    "result": {
        "status_code": 404,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 404,
            "message": "Requested STORAGE POOL not found."
        }
    }
}
"""
"""
@apiGroup Pools
@apiName UpdateParticularPool
@api {put} /ise/<ise-id>/pools/<pool-id> Update Particular Pool
@apiParam {Integer} ise-id unique ISE ID.
@apiParam {Integer} pool-id unique Pool ID.

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for updating particular pool info.
@apiSuccess {String} message It gives success or error message.
@apiSuccess {String} error It contains error message.

@apiSuccessExample Success-Response:
HTTP/1.1 200
@apiErrorExample Error-Response:
HTTP/1.1 404 Not Found
{
    "message": "fail",
    "time_taken": {
        "python": "0.00s",
        "req_recv_time": "1504446029",
        "total": "3.85s",
        "cortex": "3.84s",
        "res_send_time": "1504446033"
    },
    "result": {
        "status_code": 404,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 404,
            "message": "Requested STORAGE POOL not found."
        }
    }
}
"""
"""
@apiGroup Pools
@apiName DeleteParticularPool
@api {delete} /ise/<ise-id>/pools/<pool-id> Delete Particular Pool
@apiParam {Integer} ise-id unique ISE ID.
@apiParam {Integer} pool-id unique Pool ID.

@apiSuccess {String} result It contains response and its attributes.
@apiSuccess {String} timetaken It contains response time taken for deleting particular pool info.
@apiSuccess {String} message It gives success or error message.
@apiSuccess {String} error It contains error message.

@apiSuccessExample Success-Response:
HTTP/1.1 200
@apiErrorExample Error-Response:
HTTP/1.1 404 Not Found
{
    "message": "fail",
    "time_taken": {
        "python": "0.01s",
        "req_recv_time": "1504446029",
        "total": "3.85s",
        "cortex": "3.84s",
        "res_send_time": "1504446033"
    },
    "result": {
        "status_code": 404,
        "response": {
            "data": []
        },
        "error": {
            "status_code": 404,
            "message": "Requested STORAGE POOL not found."
        }
    }
}
"""
urlpatterns = [
    url(r'^ise/(?P<ise_id>[\w\-]+)/pools/(?P<pool_id>[\w\-]+)/$', PoolsDetail.as_view()),
    url(r'^ise/(?P<ise_id>[\w\-]+)/pools-chart/$', PoolsChart.as_view()),
    url(r'^ise/(?P<ise_id>[\w\-]+)/pools/$', PoolsList.as_view()),
    url(r'^ise/(?P<ise_id>[\w\-]+)/datareduction/$', DataReduction.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
