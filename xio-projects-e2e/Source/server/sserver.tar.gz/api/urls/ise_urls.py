from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns
from api.views.ise_views import (IseList, IseDetail, IseSanMap,
                                 SanIseMap, IseManagement, AdvancedSettings,
                                 IseStatus, IseLed, Initialize)
"""
@apiGroup ISE
@apiName AdvancedSettings
@api {get} /ise/<ise-id>/advance-settings/ Display AdvancedSettingsInfo

@apiSuccess {String} result Displays the result
@apiSuccess {Integer} response It gives response as status code
@apiSuccess {String} data  It contains attributes of the AdvancedSettings

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "result": "success",
    "response": {
        "data": {
            "running": true,
            "warning": false,
            "identify": false,
            "shutdown": false,
            "initialize": false,
            "reformat": false,
            "restart": false
        }
    }
}
"""
"""
@apiGroup ISE
@apiName SanIseMap
@api {get} /ise/<ise-id>/sangroup_map/ Display SanIseMapInfo

@apiSuccess {String} result Displays the result
@apiSuccess {Integer} response It gives response as status code
@apiSuccess {String} data  It contains attributes of the SanIseMap

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
[
    {
        "sangroup_id": 2,
        "checked": false,
        "sangroup_name": "msys"
    },
    {
        "sangroup_id": 3,
        "checked": false,
        "sangroup_name": "msys-test"
    },
    {
        "sangroup_id": 1,
        "checked": true,
        "sangroup_name": "Test"
    }
]
"""
"""
@apiGroup ISE
@apiName IseSanMap
@api {get} /sangroup/<id>/ise_map/ Display IseSanMapInfo

@apiSuccess {String} result Displays the result
@apiSuccess {Integer} response It gives response as status code
@apiSuccess {String} data  It contains attributes of the IseSanMap

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
[
    {
        "ise_name": "Test1",
        "checked": true,
        "id": 1
    }
]
"""
"""
@apiGroup ISE
@apiName IseDetail
@api {get} /ise-details/<id>/ Display IseDetail

@apiSuccess {String} result Displays the result
@apiSuccess {Integer} response It gives response as status code
@apiSuccess {String} data  It contains attributes of the IseDetail

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
{
    "ip_secondary": "10.20.225.136",
    "ise_name": "Test1",
    "raw_data": "{\"status\":{\"status\":\"\",\"_attr\":{\"string\":\"Warning\",\"value\":\"1\"}},\"serialnumber\":\"3DE100RT\",\"vendor\":\"XIOTECH\",\"name\":\"Test1\",\"globalid\":\"3DE100RT\",\"_attr\":{\"self\":\"http://10.20.225.136/storage/arrays/3DE100RT\"},\"capabilities\":[{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Storage\",\"value\":\"3\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Block Server\",\"value\":\"15\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Basic ISE Mirror\",\"value\":\"40001\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"ISE Data Migration\",\"value\":\"40002\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"ISE Mirror Copy\",\"value\":\"40003\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Active-Active ISE Mirror\",\"value\":\"40004\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"ISE Mirror Witness\",\"value\":\"40005\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Orchestrator-disabled\",\"value\":\"47001\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Performance Response Time in Microseconds\",\"value\":\"49001\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"IO Access Mapping\",\"value\":\"49002\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Volume Affinity\",\"value\":\"49003\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Volume Quality of Service IOPS\",\"value\":\"49004\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Thin Provisioning\",\"value\":\"49005\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Clones\",\"value\":\"49006\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Thin-Clones\",\"value\":\"49007\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Thin CADP\",\"value\":\"49008\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Affinity Conversion\",\"value\":\"49009\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"Thick to Thin Conversion\",\"value\":\"49010\"}},{\"capability\":\"\",\"_attr\":{\"type\":\"source\",\"string\":\"One Step Snap Create\",\"value\":\"49011\"}}],\"controllers\":{\"controllers\":[{\"status\":{\"status\":\"\",\"_attr\":{\"string\":\"Warning\",\"value\":\"1\"}},\"macaddress\":\"00:1F:93:20:03:30\",\"_attr\":{\"self\":\"http://10.20.225.136/storage/arrays/3DE100RT/controllers/1\"},\"rank\":{\"_attr\":{\"string\":\"Primary\",\"value\":\"1\"},\"rank\":\"\"},\"fwversion\":\"v3.3.1-5098\",\"dnsname\":\"10.20.225.136\",\"ipaddress\":\"10.20.225.48\"},{\"status\":{\"status\":\"\",\"_attr\":{\"string\":\"Warning\",\"value\":\"1\"}},\"macaddress\":\"00:1F:93:20:03:88\",\"_attr\":{\"self\":\"http://10.20.225.136/storage/arrays/3DE100RT/controllers/2\"},\"rank\":{\"_attr\":{\"string\":\"Secondary\",\"value\":\"0\"},\"rank\":\"\"},\"fwversion\":\"v3.3.1-5098\",\"dnsname\":\"10.20.225.48\",\"ipaddress\":\"10.20.225.136\"}],\"_attr\":{\"self\":\"http://10.20.225.136/storage/arrays/3DE100RT/controllers\"}},\"chronometer\":{\"timezone\":\"MST\",\"dst\":\"disabled\",\"_attr\":{\"date\":\"21-Apr-2017\",\"time\":\"00:39:35\"},\"timezonesetting\":\"MST\"},\"model\":\"ISE3401\",\"id\":\"2000001F93104B00\"}",
    "serial_no": "3DE100RT",
    "mrc1_status": true,
    "username": "administrator",
    "status": 0,
    "root_node_id": null,
    "time_stamp": "2017-04-21T06:47:45.986900Z",
    "password": "administrator",
    "mrc2_status": true,
    "id": 1,
    "ip_primary": "10.20.225.48"
}
"""
"""
@apiGroup ISE
@apiName IseList
@api {get} /ises/ Display IseList

@apiSuccess {String} result Displays the result
@apiSuccess {Integer} response It gives response as status code
@apiSuccess {String} data  It contains attributes of the IseList

@apiSuccessExample Success-Response:
HTTP/1.1 200 OK
[
    {
        "id": 1,
        "root_node_id": null,
        "ise_name": "Test1",
        "raw_data": "\"{\\\"status\\\":{\\\"status\\\":\\\"\\\",\\\"_attr\\\":{\\\"string\\\":\\\"Warning\\\",\\\"value\\\":\\\"1\\\"}},\\\"serialnumber\\\":\\\"3DE100RT\\\",\\\"vendor\\\":\\\"XIOTECH\\\",\\\"name\\\":\\\"Test1\\\",\\\"globalid\\\":\\\"3DE100RT\\\",\\\"_attr\\\":{\\\"self\\\":\\\"http://10.20.225.136/storage/arrays/3DE100RT\\\"},\\\"capabilities\\\":[{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Storage\\\",\\\"value\\\":\\\"3\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Block Server\\\",\\\"value\\\":\\\"15\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Basic ISE Mirror\\\",\\\"value\\\":\\\"40001\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"ISE Data Migration\\\",\\\"value\\\":\\\"40002\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"ISE Mirror Copy\\\",\\\"value\\\":\\\"40003\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Active-Active ISE Mirror\\\",\\\"value\\\":\\\"40004\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"ISE Mirror Witness\\\",\\\"value\\\":\\\"40005\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Orchestrator-disabled\\\",\\\"value\\\":\\\"47001\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Performance Response Time in Microseconds\\\",\\\"value\\\":\\\"49001\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"IO Access Mapping\\\",\\\"value\\\":\\\"49002\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Volume Affinity\\\",\\\"value\\\":\\\"49003\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Volume Quality of Service IOPS\\\",\\\"value\\\":\\\"49004\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Thin Provisioning\\\",\\\"value\\\":\\\"49005\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Clones\\\",\\\"value\\\":\\\"49006\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Thin-Clones\\\",\\\"value\\\":\\\"49007\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Thin CADP\\\",\\\"value\\\":\\\"49008\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Affinity Conversion\\\",\\\"value\\\":\\\"49009\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"Thick to Thin Conversion\\\",\\\"value\\\":\\\"49010\\\"}},{\\\"capability\\\":\\\"\\\",\\\"_attr\\\":{\\\"type\\\":\\\"source\\\",\\\"string\\\":\\\"One Step Snap Create\\\",\\\"value\\\":\\\"49011\\\"}}],\\\"controllers\\\":{\\\"controllers\\\":[{\\\"status\\\":{\\\"status\\\":\\\"\\\",\\\"_attr\\\":{\\\"string\\\":\\\"Warning\\\",\\\"value\\\":\\\"1\\\"}},\\\"macaddress\\\":\\\"00:1F:93:20:03:30\\\",\\\"_attr\\\":{\\\"self\\\":\\\"http://10.20.225.136/storage/arrays/3DE100RT/controllers/1\\\"},\\\"rank\\\":{\\\"_attr\\\":{\\\"string\\\":\\\"Primary\\\",\\\"value\\\":\\\"1\\\"},\\\"rank\\\":\\\"\\\"},\\\"fwversion\\\":\\\"v3.3.1-5098\\\",\\\"dnsname\\\":\\\"10.20.225.136\\\",\\\"ipaddress\\\":\\\"10.20.225.48\\\"},{\\\"status\\\":{\\\"status\\\":\\\"\\\",\\\"_attr\\\":{\\\"string\\\":\\\"Warning\\\",\\\"value\\\":\\\"1\\\"}},\\\"macaddress\\\":\\\"00:1F:93:20:03:88\\\",\\\"_attr\\\":{\\\"self\\\":\\\"http://10.20.225.136/storage/arrays/3DE100RT/controllers/2\\\"},\\\"rank\\\":{\\\"_attr\\\":{\\\"string\\\":\\\"Secondary\\\",\\\"value\\\":\\\"0\\\"},\\\"rank\\\":\\\"\\\"},\\\"fwversion\\\":\\\"v3.3.1-5098\\\",\\\"dnsname\\\":\\\"10.20.225.48\\\",\\\"ipaddress\\\":\\\"10.20.225.136\\\"}],\\\"_attr\\\":{\\\"self\\\":\\\"http://10.20.225.136/storage/arrays/3DE100RT/controllers\\\"}},\\\"chronometer\\\":{\\\"timezone\\\":\\\"MST\\\",\\\"dst\\\":\\\"disabled\\\",\\\"_attr\\\":{\\\"date\\\":\\\"21-Apr-2017\\\",\\\"time\\\":\\\"00:39:35\\\"},\\\"timezonesetting\\\":\\\"MST\\\"},\\\"model\\\":\\\"ISE3401\\\",\\\"id\\\":\\\"2000001F93104B00\\\"}\"",
        "serial_no": "3DE100RT",
        "ip_primary": "10.20.225.48",
        "ip_secondary": "10.20.225.136",
        "mrc1_status": true,
        "mrc2_status": true,
        "username": "administrator",
        "password": "administrator",
        "time_stamp": "2017-04-21T06:47:45.986900Z",
        "status": 0,
        "sangroup": [
            {
                "comment": "",
                "sangroup_name": "Test",
                "sangroup_id": 1
            }
        ]
    }
]
"""
urlpatterns = [
    url(r'^ise/(?P<id>[\w\-]+)/advance-settings/$', AdvancedSettings.as_view()),
    url(r'^ise/(?P<id>[\w\-]+)/management/$', IseManagement.as_view()),
    url(r'^ise/(?P<id>[\w\-]+)/sangroup_map/$', SanIseMap.as_view()),
    url(r'^ise/(?P<id>[\w\-]+)/status/$', IseStatus.as_view()),
    url(r'^ise/(?P<id>[\w\-]+)/initialize/$', Initialize.as_view()),
    url(r'^ise/(?P<id>[\w\-]+)/led/$', IseLed.as_view()),
    url(r'^sangroup/(?P<id>[\w\-]+)/ise-map/$', IseSanMap.as_view()),
    url(r'^ise-details/(?P<id>[\w\-]+)/$', IseDetail.as_view()),
    # url(r'^ises/$', IseList.as_view()),
    url(r'^ise-list/', IseList.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
