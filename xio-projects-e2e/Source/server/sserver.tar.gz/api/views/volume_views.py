from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from api.models.ise_models import ListIse
import urllib
import time
import re
import timeit

# other library
from lib.generic_request import GenericRequests
from utility.dynamic_url_formation import dynamic_url
from lib.client_response import ClientResponse
from config import (AUTH, HEADER_JSON, RESOURCE)
from lib.group_permission import User_Permision

req_obj = GenericRequests()
res_obj = ClientResponse()


class VolumesList(APIView):
    """To get all volumes based on ise id""" 

    def __init__(self):
        self.cortex_start = 0.0
        self.cortex_total = 0.0

    def get(self, request, ise_id, format=None):

        start_time = timeit.default_timer()

        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            self.cortex_start = timeit.default_timer()
            url_dynamic = get_url[0]
            AUTH = get_url[1]
            url = url_dynamic+RESOURCE['volumes']
            res  = req_obj.send_request(url, AUTH, headers=HEADER_JSON)
            self.cortex_total = timeit.default_timer() - self.cortex_start
            (response, status_code) = res_obj.client_response(res)
            if response.get('message') == 'success':
                vol_res = response['result']['response']['data']['volumes']

                if vol_res.has_key('volume'):
                    vol_res['volume']['ise_id'] = ise_id
                    vol_res['volume']['volume_id'] = vol_res['volume']['id']
                    if vol_res['volume']['allocations'].has_key('allocation'):
                        vol_res['volume']['allocation']= [vol_res['volume']['allocations']['allocation']]
                    else:
                        if vol_res['volume']['allocations']['allocations']:
                            vol_res['volume']['allocation']= vol_res['volume']['allocations']['allocations']
                        else:
                            vol_res['volume']['allocation']= []

                elif vol_res.has_key('volumes'):
                    for i in range(len(vol_res['volumes'])):
                        vol_res['volumes'][i]['ise_id'] = ise_id
                        vol_res['volumes'][i]['volume_id'] = vol_res['volumes'][i]['id']
                        if vol_res['volumes'][i]['allocations'].has_key('allocation'):
                            # vol_res['volumes'][i]['allocation'] = []
                            vol_res['volumes'][i]['allocation']=[vol_res['volumes'][i]['allocations']['allocation']]
                        else:
                            vol_res['volumes'][i]['host_id'] = vol_res['volumes'][i]['id']
                            vol_res['volumes'][i]['ise_id'] = ise_id
                            for i in range(len(vol_res['volumes'])):
                                # vol_res['volumes'][i]['allocation'] = []
                                if vol_res['volumes'][i]['allocations'].has_key('allocations'):
                                    if vol_res['volumes'][i]['allocations']['allocations']:
                                        vol_res['volumes'][i]['allocation']=vol_res['volumes'][i]['allocations']['allocations']
                                    else:
                                        vol_res['volumes'][i]['allocation']=[]

                                else:
                                    vol_res['volumes'][i]['allocation']=[vol_res['volumes'][i]['allocations']['allocation']]
                else:
                    pass
            # if response['response']['data']['volumes'].has_key('volume'):
            #     response['response']['data']['volumes']['volumes'] = response['response']['data']['volumes'].pop('volume')
            # elif response['response']['data']['volumes'].has_key('volumes'):
            #     pass
            # else:
            #     response['response']['data']['volumes']['volumes'] = []

            # response['volume_available'] = 240 - len(response['response']['data']['volumes']['volumes'])
            total_time = timeit.default_timer() - start_time
            process_time = total_time - self.cortex_total
            if response.has_key('time_taken'):
                response['time_taken']['req_recv_time'] = "%d"%int(start_time)
                response['time_taken']['cortex'] = "%.2fs"%self.cortex_total
                response['time_taken']['python'] = "%.2fs"%process_time
                response['time_taken']['total'] = "%.2fs"%total_time
                response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())

            return Response(response, status=status_code)

    # @User_Permision('add_volume')
    def post(self, request, ise_id, format=None):
        """
        """
        request_data = request.data
        volume_name = request_data['name']
        host_names = request_data['host_list']

        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            url_dynamic = get_url[0]
            AUTH = get_url[1]

            url = url_dynamic + RESOURCE['volumes']
            all_payload = {}
            query_string = urllib.urlencode(request.data, doseq=True)
            res = req_obj.send_request(url, AUTH, headers=HEADER_JSON, data=query_string, method='POST')

            if res['message'] == 'success':
                volume_res = res['result']['response']['data']
                volume_id = re.search(r'\((.*?)\)', volume_res).group(1)
                
                if volume_id:
                    allocation_url = url_dynamic + RESOURCE['allocations']
                    all_payload['volumename'] = volume_name
                    # volume_id = volume_res[volume_res.find("(") + 1:volume_res.find(")")]
                    
                else:
                    volume_guid = False
                    while volume_guid == False:
                        volume_response = req_obj.send_request(url, AUTH, headers=HEADER_JSON)
                        volume_data = volume_response['result']['response']['data']['volumes']
                        if volume_data.has_key('volume'):
                            if volume_data['volume']['name'] == request.data['name']:
                                if volume_data['volume']['id']:
                                    volume_id = volume_data['volume']['id']
                                    volume_guid = True
                        
                        elif volume_data.has_key('volumes'):
                            for i in range(len(volume_data['volumes'])):
                                if volume_data['volumes'][i]['name'] == request.data['name']:
                                    if volume_data['volume']['id']:
                                        volume_id = volume_data['volume']['id']
                                        volume_guid = True
                        else:
                            pass
                        
                volume_get_url = url_dynamic + RESOURCE['volumes'] + '/' + volume_id
                vol_get_res = req_obj.send_request(volume_get_url, AUTH, headers=HEADER_JSON)
                volume_created = False

                while volume_created == False:
                    if vol_get_res['result']['status_code'] == 200:
                        if vol_get_res['result']['response']['data']['volumes'].has_key('volume'):
                            if vol_get_res['result']['response']['data']['volumes']['volume']['status']['_attr']['string'] == 'Operational':
                                volume_created = True
                                for host_name in host_names:
                                    if host_name['host'] != False:
                                        all_payload['hostname'] = host_name['label']
                                        all_payload['lun'] = host_name['lun']
                                        allocation_res = req_obj.send_request(allocation_url, AUTH, headers=HEADER_JSON,
                                                                              data=all_payload, method='POST')
                                        if allocation_res.get('message') == 'fail':
                                            (response, status_code) = res_obj.response_formation(allocation_res['result']['response']['data'], status.HTTP_400_BAD_REQUEST)
                                            return Response(response, status=status_code)
                            else:
                                vol_get_res = req_obj.send_request(volume_get_url, AUTH, headers=HEADER_JSON)
                        else:
                            vol_get_res = req_obj.send_request(volume_get_url, AUTH, headers=HEADER_JSON)
                    else:
                        vol_get_res = req_obj.send_request(volume_get_url, AUTH, headers=HEADER_JSON)

                if request.data['create_like_volumes'] == True:
                    req_name = request_data['name']
                    for i in range(int(request.data['no_like_volumes'])):
                        request_data['name'] = req_name + "-" + str(i+1).zfill(3)
                        query_string = urllib.urlencode(request_data, doseq=True)
                        res_like = req_obj.send_request(url, AUTH, headers=HEADER_JSON, data=query_string, method='POST')

                (response, status_code) = res_obj.response_formation(res['result']['response']['data'], status.HTTP_200_OK)
                return Response(response, status=status_code)
            
            else:
                (response, status_code) = res_obj.client_response(res)
                return Response(response, status=status_code)



class VolumeDetail(APIView):
    """Retrieve,Update or Delete a volumes instance"""
    def __init__(self):
        self.cortex_start = 0.0
        self.cortex_total = 0.0

    def get_object(self, ise_id, volume_id):
        """To get particular object"""
        start_time = timeit.default_timer()
        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            self.cortex_start = timeit.default_timer()
            url_dynamic = get_url[0]
            AUTH = get_url[1]
            url = url_dynamic + RESOURCE['volumes'] + "/" + volume_id
            res = req_obj.send_request(url, AUTH, headers=HEADER_JSON)
            self.cortex_total = timeit.default_timer() - self.cortex_start
            (response, status_code) = res_obj.client_response(res)
            total_time = timeit.default_timer() - start_time
            process_time = total_time - self.cortex_total
            if response.has_key('time_taken'):
                response['time_taken']['cortex'] = "%.2fs"%self.cortex_total
                response['time_taken']['python'] = "%.2fs"%process_time
                response['time_taken']['total'] = "%.2fs"%total_time
                response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
                response['time_taken']['req_recv_time'] = "%d"%int(start_time)
            return Response(response, status=status_code)

    def get(self, request,  ise_id, volume_id,format=None):
        """Get particular volume based on it's id"""

        return self.get_object(ise_id, volume_id)

    # @User_Permision('change_volume')
    def put(self, request, ise_id, volume_id, format=None):
        """Update particular volume based on it's id
            res = requests.put('http://10.20.225.136/storage/arrays/3DE100RT/volumes/6001F93104B00000F85C000200000000',params=payload,headers=HEADER_JSON,auth=AUTH)
        """
        payload = dict(request.data)
        allocate_out = {}

        for key,value in payload.iteritems():
            if key == 'alloctype':
                allocate_out = {key:value}
        if allocate_out:
            payload.pop('alloctype')
            
        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            url_dynamic = get_url[0]
            AUTH = get_url[1]
            url = url_dynamic + RESOURCE['volumes'] + "/" + volume_id
            if allocate_out:
                res = req_obj.send_request(url, AUTH, headers=HEADER_JSON, data=allocate_out, method='PUT')
                if res['message'] == 'fail':
                    (response, status_code) = res_obj.client_response(res)
                    return Response(response, status=status_code)
            res = req_obj.send_request(url, AUTH, headers=HEADER_JSON, data=payload, method='PUT')
            (response, status_code) = res_obj.client_response(res)
            return Response(response, status=status_code)

    # @User_Permision('delete_volume')
    def delete(self, request, volume_id, ise_id, format=None):
        """Delete particular volume based on it's id"""
        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            url_dynamic = get_url[0]
            AUTH = get_url[1]
            url = url_dynamic + RESOURCE['volumes'] + "/" + volume_id
            res = req_obj.send_request(url, AUTH, headers=HEADER_JSON, method='DELETE')
            if res['message'] == 'success':
                (response, status_code) = res_obj.response_formation({'deleted_volume':volume_id},status.HTTP_200_OK)
                return Response(response, status=status_code)
            (response, status_code) = res_obj.client_response(res)
            return Response(response, status=status_code)

class Allocation(APIView):
    """mapping volume with multiple hosts"""

    def put(self, request, ise_id, format=None):

        """Update particular volume based on it's id
            res = requests.put('http://10.20.225.136/storage/arrays/3DE100RT/volumes/6001F93104B00000F85C000200000000',params=payload,headers=HEADER_JSON,auth=AUTH)
            {"volumename":"name",
                "volumeid":"3423423",
                "present":[""],
                "unpresent":["6001F93104B00000FA080002000000002000001F93104B002101001B322E865D"]
            }
        """
        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            url_dynamic = get_url[0]
            AUTH = get_url[1]
            req = dict(request.data)
            res = {"message": "fail", "result": {}}
            
            if req.get('present'):
                pr_url = url_dynamic + RESOURCE['allocations']
                temp = {}
                temp['volumename'] = req['volume_name']
                for host_name in req['present']:
                    temp['hostname'] = host_name['host']
                    temp['lun'] = host_name['lun']
                    data_string = urllib.urlencode(temp)
                    pr_res = req_obj.send_request(pr_url, AUTH, headers=HEADER_JSON, data=data_string, method='POST')
                res = pr_res

            if req.get('unpresent'):
                for allocationid in req['unpresent']:
                    upr_url = url_dynamic + RESOURCE['allocations'] + "/" + str(allocationid)
                    upr_res = req_obj.send_request(upr_url, AUTH, headers=HEADER_JSON, method='DELETE')
                res = upr_res

            if req.get('changed'):
                temp = {}
                for change in req['changed']:
                    allocationid = change.get('globalID')
                    temp['lun'] = change.get('lun')
                    data_string = urllib.urlencode(temp)
                    modify_url = url_dynamic + RESOURCE['allocations'] + "/" + str(allocationid)
                    change_res = req_obj.send_request(modify_url, AUTH, headers=HEADER_JSON, data=data_string, method='PUT')
                res = change_res
            if res.get('message') != 'fail':
                (response, status_code) = res_obj.response_formation("Volume allocation updated successfully",status.HTTP_200_OK)
            else:
                (response, status_code) = res_obj.response_formation("Volume allocation failed",status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)

class VolumeChart(APIView):

    def __init__(self):
        self.cortex_start = 0.0
        self.cortex_total = 0.0

    def get(self, request, ise_id, format=None):
        start_time = timeit.default_timer()
        get_url = dynamic_url(ise_id)
        if get_url == status.HTTP_404_NOT_FOUND:
            (response, status_code) = res_obj.response_formation('ISE Not Found', status.HTTP_404_NOT_FOUND)
            return Response(response, status=status_code)

        elif get_url == status.HTTP_504_GATEWAY_TIMEOUT:
            (response, status_code) = res_obj.response_formation('Connection Refused...', status.HTTP_504_GATEWAY_TIMEOUT)
            return Response(response, status=status_code)

        else:
            self.cortex_start = timeit.default_timer()
            url_dynamic = get_url[0]
            AUTH = get_url[1]
            url = url_dynamic + RESOURCE['volumes']
            res = req_obj.send_request(url, AUTH, headers=HEADER_JSON)
            self.cortex_total = timeit.default_timer() - self.cortex_start
            if res['message']=='success':
                volume_total = {}
                volume_list = []
                data = res['result']['response']['data']
                if data.has_key('volumes'):
                    if data['volumes'].has_key('volume'):
                        volume_list.append(data['volumes']['volume'])
                    elif data['volumes'].has_key('volumes'):
                        volume_list.extend(data['volumes']['volumes'])
                    else:
                        res['result']['response']['data']['volumes']['volumes'] = []
                else:
                    res['result']['response']['data']['volumes']['volumes'] = []
                    
                total_size = 0
                total_allocpercent = 0
                for volume in volume_list:
                    total_size = total_size+float(volume['size'])
                    total_allocpercent = total_allocpercent+(float(volume['allocpercent'])*float(volume['size']))
                volume_total = {
                    'overall_size':int(total_size),
                    'overall_allocpercent':int(total_allocpercent)
                }
                res['result']['response']['data'].pop('volumes')
                res['result']['response']['data'].update(volume_total)
                (response, status_code) = res_obj.client_response(res)
                total_time = timeit.default_timer() - start_time
                process_time = total_time - self.cortex_total
                if response.has_key('time_taken'):
                    response['time_taken']['cortex'] = "%.2fs"%process_time
                    response['time_taken']['python'] = "%.2fs"%self.cortex_total
                    response['time_taken']['total'] = "%.2fs"%total_time
                    response['time_taken']['req_recv_time'] = "%d"%int(start_time)
                    response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
                return Response(response, status=status_code)
            else:
                (response, status_code) = res_obj.client_response(res)
                return Response(response, status=status_code)
