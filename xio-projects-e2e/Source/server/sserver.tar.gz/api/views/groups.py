from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth.models import (User, Group, Permission)
from rest_framework import status
import timeit

from api.serializer.group_serializer import (GroupSerializer,
                                             PermissionSerializer)
from lib.client_response import ClientResponse
from lib.group_permission import User_Permision
res_obj = ClientResponse()


class GroupList(APIView):
    '''List of Groups and Create New Groups'''

    def get(self, request, format=None):
        start_time = timeit.default_timer()
        groups = Group.objects.all()
        group = GroupSerializer(groups, many=True)
        for i in range(len(group.data)):
            group.data[i].setdefault('sudo_group', False)
            if group.data[i].get('name') == 'Administrators':
                group.data[i]['sudo_group'] = True        
        (response, status_code) = res_obj.response_formation(group.data, status.HTTP_200_OK)
        total_time = timeit.default_timer() - start_time
        if response.has_key('time_taken'):
            response['time_taken']['cortex'] = "0.0s"
            response['time_taken']['python'] = "%.2fs"%total_time
            response['time_taken']['total'] = "%.2fs"%total_time
            response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
            response['time_taken']['req_recv_time'] = "%d"%int(start_time)
        return Response(response, status=status_code)

    # @User_Permision('add_group')
    def post(self, request, format=None):
        try:
            group = Group.objects.create(name=request.data.get('name'))
            if 'permissions' in request.data:
                for permission in request.data['permissions']:
                    group.permissions.add(permission)
            (response, status_code) = res_obj.response_formation('New Group created Succesfully', status.HTTP_201_CREATED)
            return Response(response, status=status_code)

        except Exception as e:
            (response, status_code) = res_obj.response_formation(str(e), status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)


class GroupDetails(APIView):
    '''Get Group information and delete the Group based on Group id'''

    def get_object(self, id):
        """To get particular Group object"""
        try:
            return Group.objects.get(id=id)
        except Group.DoesNotExist:
            return None

    def get(self, request, id, format=None):
        """Get particular Group based on it's id"""
        start_time = timeit.default_timer()
        group_obj = self.get_object(id)

        if group_obj:
            group_serializer = GroupSerializer(group_obj)
            (response, status_code) = res_obj.response_formation(group_serializer.data, status.HTTP_200_OK)
            total_time = timeit.default_timer() - start_time
            if response.has_key('time_taken'):
                response['time_taken']['cortex'] = "0.0s"
                response['time_taken']['python'] = "%.2fs"%total_time
                response['time_taken']['total'] = "%.2fs"%total_time
                response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
                response['time_taken']['req_recv_time'] = "%d"%int(start_time)
            return Response(response, status=status_code)

        (response, status_code) = res_obj.response_formation('Group Not Found', status.HTTP_404_NOT_FOUND)
        total_time = timeit.default_timer() - start_time
        if response.has_key('time_taken'):
            response['time_taken']['cortex'] = "0.0s"
            response['time_taken']['python'] = "%.2fs"%total_time
            response['time_taken']['total'] = "%.2fs"%total_time
            response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
            response['time_taken']['req_recv_time'] = "%d"%int(start_time)
        return Response(response, status=status_code)

    # @User_Permision('change_group')
    def put(self, request, id, format=None):
        """Update particular Group based on it's id"""

        group = self.get_object(id)
        if request.data.get('name') == 'Administrators':
            (response, status_code) = res_obj.response_formation('Administrator group cannot be edited', status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)

        serializer = GroupSerializer(group, data=request.data)
        if serializer.is_valid():
            serializer.save()
            if 'permissions' in request.data:
                for permission in request.data['permissions']:
                    group.permissions.add(permission)
            (response, status_code) = res_obj.response_formation(serializer.data, status.HTTP_200_OK)
            return Response(response, status=status_code)
        (response, status_code) = res_obj.response_formation(serializer.errors, status.HTTP_400_BAD_REQUEST)
        return Response(response, status=status_code)

    # @User_Permision('delete_group')
    def delete(self, request, id, format=None):
        """Delete particular Group based on it's id"""
        group_obj = self.get_object(id)
        user_obj = User.objects.filter(groups__id=id)
        if group_obj.name == 'Administrators':
            (response, status_code) = res_obj.response_formation('Administrator group cannot be deleted',
                                                                 status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)

        if len(user_obj) == 0:
            group_obj.delete()
            (response, status_code) = res_obj.response_formation({'deleted_group':group_obj.name}, status.HTTP_200_OK)
            return Response(response, status=status_code)

        else:
            (response, status_code) = res_obj.response_formation('User exists in the Group',
                                                                 status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)


class PermissionList(APIView):

    def get(self, request, format=None):
        """
        """
        permissions = Permission.objects.all()
        permission = PermissionSerializer(permissions, many=True)
        (response, status_code) = res_obj.response_formation(permission.data, status.HTTP_200_OK)
        return Response(response, status_code)
