from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import jwt
import copy
import timeit

from django.contrib.auth.models import (User, Group, Permission)
from api.models.ise_models import ListIse
from api.serializer.user_serializer import UserSerializer
from lib.client_response import ClientResponse
from config import (secret)
from lib.group_permission import User_Permision
from config import secret

res_obj = ClientResponse()


class UsersList(APIView):
    '''List of Users and Create New Users'''

    # @User_Permision('add_user')
    def get(self, request, format=None):
        start_time = timeit.default_timer()
        users = User.objects.all()
        user = UserSerializer(users, many=True)
        # for itm in user.data:
        #     if itm['groups']:
        #         group_obj = Group.objects.values(
        #             'name').filter(id=itm['groups'][0])
        #         itm['group_name'] = [groups['name'] for groups in group_obj]
        #     else:
        #         itm['group_name'] = []
        for i in range(len(user.data)):
            user.data[i].setdefault('sudo_user', False)
            if user.data[i].get('username') == 'Administrator':
                user.data[i]['sudo_user'] = True
        (response, status_code) = res_obj.response_formation(user.data, status.HTTP_200_OK)
        total_time = timeit.default_timer() - start_time
        if response.has_key('time_taken'):
            response['time_taken']['cortex'] = "0.0s"
            response['time_taken']['python'] = "%.2fs"%total_time
            response['time_taken']['total'] = "%.2fs"%total_time
            response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
            response['time_taken']['req_recv_time'] = "%d"%int(start_time)
        return Response(response, status=status_code)

    #@User_Permision('add_user')
    def post(self, request, format=None):
        user_info = request.data
        try:
            user = User.objects.create_user(user_info['username'],
                                            user_info['email'], user_info['password'])
            user.first_name = user_info['first_name']
            user.last_name = user_info['last_name']
            # user.is_active = user_info['is_active']
            # user.is_staff = user_info['is_staff']
            user.save()
            # user.groups.add(Group.objects.get(id=user_info['group_id']))
            (response, status_code) = res_obj.response_formation('New User Created Succesfully',
                                                                 status.HTTP_201_CREATED)
            return Response(response, status=status_code)

        except Exception as e:
            (response, status_code) = res_obj.response_formation(
                str(e), status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)


class UserDetails(APIView):
    '''Get user information and delete the user based on user id'''

    def get_object(self, id):
        """To get particular User object"""
        try:
            return User.objects.get(id=id)
        except User.DoesNotExist:
            return None

    def get(self, request, id, format=None):
        """Get particular User based on it's id"""
        start_time = timeit.default_timer()
        user_obj = self.get_object(id)
        if user_obj:
            user_serializer = UserSerializer(user_obj)
            (response, status_code) = res_obj.response_formation(user_serializer.data, status.HTTP_200_OK)
            total_time = timeit.default_timer() - start_time
            if response.has_key('time_taken'):
                response['time_taken']['req_recv_time'] = "%d"%int(start_time)
                response['time_taken']['cortex'] = "0.0s"
                response['time_taken']['python'] = "%.2fs"%total_time
                response['time_taken']['total'] = "%.2fs"%total_time
                response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
            return Response(response, status=status_code)

        (response, status_code) = res_obj.response_formation('User Not Found', status.HTTP_404_NOT_FOUND)
        total_time = timeit.default_timer() - start_time
        if response.has_key('time_taken'):
            response['time_taken']['req_recv_time'] = "%d"%int(start_time)
            response['time_taken']['cortex'] = "0.0s"
            response['time_taken']['python'] = "%.2fs"%total_time
            response['time_taken']['total'] = "%.2fs"%total_time
            response['time_taken']['res_send_time'] = "%d"%int(timeit.default_timer())
        return Response(response, status=status_code)
    #@User_Permision('change_user')
    def put(self, request, id, format=None):
        """Update particular User based on it's id"""
        user_info = request.data
        token = request.META['HTTP_AUTHORIZATION']
        session_user = jwt.decode(token[4:], secret, algorithm='HS256')
        user = self.get_object(id)
        serializer = UserSerializer(user, data=request.data)
        if user.username == session_user['username']:
            if serializer.is_valid():
                if user_info['is_active'] == False:
                    (response, status_code) = res_obj.response_formation('User cannot change their state',
                                                                         status.HTTP_400_BAD_REQUEST)
                    return Response(response, status=status_code)
                else:
                    serializer.save()
                    # grp = Group.objects.get(id=request.data['groups'][0])
                    # user.groups.clear()
                    # user.groups.add(grp)
                    (response, status_code) = res_obj.response_formation(
                        serializer.data, status.HTTP_200_OK)
                    return Response(response, status=status_code)

        elif serializer.is_valid():
            serializer.save()
            # grp = Group.objects.get(id=request.data['groups'][0])
            # user.groups.clear()
            # user.groups.add(grp)
            (response, status_code) = res_obj.response_formation(
                serializer.data, status.HTTP_200_OK)
            return Response(response, status=status_code)
        else:
            (response, status_code) = res_obj.response_formation(
                serializer.errors, status.HTTP_400_BAD_REQUEST)
            return Response(serializer.errors, status=status_code)

    #@User_Permision('delete_user')
    def delete(self, request, id, format=None):
        """Delete particular User based on it's id"""
        token = request.META['HTTP_AUTHORIZATION']
        session_user = jwt.decode(token[4:], secret, algorithm='HS256')
        user_obj = User.objects.get(id=id)
        if user_obj.username == session_user['username']:
            (response, status_code) = res_obj.response_formation('User cannot delete own account',
                                                                 status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)

        # if user_obj.is_staff:
        #     (response, status_code) = res_obj.response_formation('Admin User cannot be deleted',
        #                                                          status.HTTP_400_BAD_REQUEST)
        #     return Response(response, status=status_code)
        else:
            user_obj.delete()
            (response, status_code) = res_obj.response_formation({'deleted_user': user_obj.username},
                                                                 status.HTTP_200_OK)
            return Response(response, status=status_code)


class Login(APIView):

    def get_object(self, name):
        """To get particular User object"""
        try:
            return User.objects.get(username=name)
        except User.DoesNotExist:
            return False

    def post(self, request, format=None):

        user = self.get_object(request.data['username'])
        if user:
            if user.check_password(request.data['password']):
                if user.is_active:
                    token = jwt.encode({'username': request.data['username']}, secret, algorithm='HS256')
                    # grp = User.objects.values('groups').filter(username=request.data['username'])
                    # if grp[0].get('groups') is None:
                    #     try:
                    #         user.groups.add(Group.objects.get(name='Administrators'))
                    #     except:
                    #         group = Group.objects.create(name='Administrators')
                    #         user.groups.add(Group.objects.get(name='Administrators'))
                    #         user.save()
                    try:
                        ise = ListIse.objects.get(prefered = 1)
                        (response, status_code) = res_obj.response_formation(
                            {'token': token, 'username': request.data['username']}, status.HTTP_200_OK)
                        response['result']['response']['data']['user_privilege'] = {'prefered_ise':ise.id}
                        return Response(response,status_code)
                    except:
                        (response, status_code) = res_obj.response_formation(
                            {'token': token, 'username': request.data['username']}, status.HTTP_200_OK)

                    # groups = User.objects.values('groups').filter(
                    #     username=request.data['username'])
                    # permission_list = Group.objects.get(
                    #     id=groups[0].get('groups')).permissions.values('codename')
                    # permission = Permission.objects.all()
                    # codename_list = []
                    # result = {}
                    # fun = {'create': False, 'update': False, 'delete': False,
                    #        'view': True, 'present': False, 'unpresent': False}
                    # permission_dict = {}

                    # for per in permission:
                    #     codename_list.append(per.codename)

                    # for per in permission:
                    #     for codename in codename_list:
                    #         try:
                    #             if result[str(codename.split('_')[1])]:
                    #                 continue
                    #         except:
                    #             result[str(codename.split('_')[1])
                    #                    ] = copy.deepcopy(fun)

                    # for p_list in permission_list:
                    #     for c_list in codename_list:
                    #         code = c_list.split('_')[1]
                    #         permission_code = p_list.get('codename')
                    #         if permission_code.split('_')[1] == code:
                    #             if str(permission_code.split('_')[0]) == "add":
                    #                 result[str(permission_code.split('_')[1])][
                    #                     'create'] = True
                    #             if str(permission_code.split('_')[0]) == "change":
                    #                 result[str(permission_code.split('_')[1])][
                    #                     'update'] = True
                    #             if str(permission_code.split('_')[0]) == "delete":
                    #                 result[str(permission_code.split('_')[1])][
                    #                     'delete'] = True

                    return Response(response, status=status_code)
                else:
                    (response, status_code) = res_obj.response_formation(
                        'User is not active', status.HTTP_400_BAD_REQUEST)
                    return Response(response, status=status_code)
            else:
                (response, status_code) = res_obj.response_formation('Invalid Username or Password',
                                                                     status.HTTP_400_BAD_REQUEST)
                return Response(response, status=status_code)

        (response, status_code) = res_obj.response_formation('Invalid Username or Password',
                                                             status.HTTP_400_BAD_REQUEST)
        return Response(response, status=status_code)


class UserPassword(APIView):

    def get_object(self, user_name):
        """To get particular User object"""
        try:
            return User.objects.get(username=user_name)
        except User.DoesNotExist:
            raise Http404

    def put(self, request, format=None):
        """Update particular UserPassword based on it's id"""
        try:
            token = request.META['HTTP_AUTHORIZATION']
            session_user = jwt.decode(token[4:], secret, algorithm='HS256')
            user = self.get_object(session_user['username'])
        except:
            (response, status_code) = res_obj.response_formation('Token Not Provided',
                                                                 status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)

        if user.username == session_user['username']:
            current = request.data['curr_password']
            new = request.data['new_password']
            confirm = request.data['confirm_password']
            if user.check_password(current):
                if user.check_password(new):
                    (response, status_code) = res_obj.response_formation('Password cannot be same',
                                                                         status.HTTP_400_BAD_REQUEST)
                    return Response(response, status=status_code)
                else:
                    if new == confirm:
                        user.set_password(new)
                        user.save()
                        (response, status_code) = res_obj.response_formation('Password Changed Succesfully',
                                                                             status.HTTP_201_CREATED)
                        return Response(response, status=status_code)
                    else:
                        (response, status_code) = res_obj.response_formation('Password doesnot match',
                                                                             status.HTTP_400_BAD_REQUEST)
                        return Response(response, status=status_code)

            else:
                (response, status_code) = res_obj.response_formation('Invalid Password',
                                                                     status.HTTP_400_BAD_REQUEST)
                return Response(response, status=status_code)
        else:
            (response, status_code) = res_obj.response_formation('Invalid User',
                                                                 status.HTTP_400_BAD_REQUEST)
            return Response(response, status=status_code)
