from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from lib.client_response import ClientResponse
from xio_ise.local_settings import BASE_DIR
import os

res_obj = ClientResponse()

class VersionInfo(APIView):
	"""
	"""
	def get(self, request, format=None):
		"""
		{
		 "version":"2.10.13-rc",
		 "major":2,
		 "minor":10,
		 "patch":13,
		 "release-type":"rc"
		}
		"""
		try:
			version_info = {}
			filename = os.path.join( BASE_DIR,'version.txt')
			with open(filename) as f:
				version_str = f.read().strip()
				if version_str:
					detail = version_str.split('.')

					version_info = {
					 "version":version_str,
					 "major":detail[0],
					 "minor":detail[1],
					 "patch":detail[0].split('-')[0],
					 "release-type":detail[0].split('-')[-1]
					}
		
				return Response(version_info, status=status.HTTP_200_OK)
		except:
			(response, status_code) = res_obj.response_formation("version file not found", status.HTTP_404_NOT_FOUND)
			return Response(response, status=status_code)