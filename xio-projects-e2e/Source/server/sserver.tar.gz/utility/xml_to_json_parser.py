from lxml import objectify
import re
from json import dumps
import requests


def flatten_attributes(property_name, lookup, attributes):
    if attributes is None:
        return lookup

    if not isinstance(lookup, dict):
        return dict(attributes.items() + [(property_name, lookup)])

    return dict(lookup.items() + attributes.items())


def xml_element_to_json(xml_element, attributes):
    
    if isinstance(xml_element, objectify.BoolElement):
        return flatten_attributes(xml_element.tag, bool(xml_element), attributes)

    if isinstance(xml_element, objectify.IntElement):
        if len(str(xml_element.text)) >= 15:
            return flatten_attributes(xml_element.tag, str(xml_element.text), attributes)
        return flatten_attributes(xml_element.tag, int(xml_element), attributes)

    # if isinstance(xml_element, objectify.LongElement):
    #     return flatten_attributes(xml_element.tag, str(xml_element.text), attributes)

    if isinstance(xml_element, objectify.FloatElement):
        return flatten_attributes(xml_element.tag, str(xml_element.text), attributes)

    if isinstance(xml_element, objectify.StringElement):
        return flatten_attributes(xml_element.tag, str(xml_element).strip(), attributes)

    return flatten_attributes(xml_element.tag, convert_xml_to_json(xml_element.getchildren()), attributes)


def convert_xml_to_json(xml_object):
    attributes = None
    if hasattr(xml_object, "attrib") and not xml_object.attrib == {}:
        attributes = dict(_attr=dict(xml_object.attrib))

    if isinstance(xml_object, objectify.ObjectifiedElement):
        return xml_element_to_json(xml_object, attributes)

    if isinstance(xml_object, list):
        if len(xml_object) > 1 and all(xml_object[0].tag == item.tag for item in xml_object):
            return [convert_xml_to_json(attr) for attr in xml_object]

        return dict([(item.tag, convert_xml_to_json(item)) for item in xml_object])

    return Exception("Not a valid lxml object")


def xml_to_json(xml):
    xml = re.sub('[&]', '', xml)
    xml_object = xml if isinstance(xml, objectify.ObjectifiedElement) \
                     else objectify.fromstring(xml)
    return dumps({xml_object.tag: convert_xml_to_json(xml_object)})


if __name__ == '__main__':
    pass
    # sample_xml = """<?xml version="1.0" encoding="ISO-8859-1"?>
    # <array self="http://10.20.225.136/storage/arrays/3DE100RT" xx="3" yy="fdgdfg">
    #     <status value="1" string="Warning"/>
    #     <globalid>3DE100RT</globalid>
    # </array>"""
    # res = requests.get('https://10.20.225.48/storage/arrays/3DE100RT/files/mgmt', auth=("administrator","administrator"), headers={"Content-Type":"application/xml"}, timeout=20, verify=False)
    # content = res.text.encode('ascii', 'ignore')

    # print content, type(content)

    # with open('sample.xml','w') as f:
    #     f.write(content)

    # with open('ISE-USE26000.xml','r') as f:
    #     temp = f.read()
    #     print type(temp)
    #     print xml_to_json(temp)
    # sample_xml = """<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><response value=\"404\" index=\"1\">Requested volume '6001F93104B00000F9AF0002000000002000001F93104B002101001B322E865D' not found.</response>"""

    # print xml_to_json(content)
    # print type(sample_xml)
