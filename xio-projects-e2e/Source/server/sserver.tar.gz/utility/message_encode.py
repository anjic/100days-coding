import json


class Global():

	pub_msg = {
		'metric':[]
	}



def message_encode(key, value):
	""" json encode the message and prepend the key """
	return key + ' ' + json.dumps(value)

def message_decode(data):
	""" Inverse of mogrify() """
	json0 = data.find('{')
	key = data[0:json0].strip()
	value = json.loads(data[json0:])
	return key, value 