import os
import subprocess
from rest_framework import status

from api.models.ise_models import ListIse
from lib.generic_request import GenericRequests
from utility.encryption import encryption, decryption
req_obj = GenericRequests()

def dynamic_url(ise_id, https=True):
    IP = None
    ise_details = {}

    try:
        ise_details = ListIse.objects.values('id','ip_primary', 'mrc1_status',
                                         'mrc2_status', 'ip_secondary',
                                         'serial_no', 'username',
                                         'password').get(id=ise_id)
    except:
        pass


    if not ise_details:
      return status.HTTP_404_NOT_FOUND

    https_str = 'http' if not https else 'https'
      

    if ise_details.get('mrc1_status'):
        IP = ise_details.get('ip_primary')
    elif ise_details.get('mrc2_status'):
        IP = ise_details.get('ip_secondary')
    else:
        return status.HTTP_504_GATEWAY_TIMEOUT


    AUTH = (ise_details.get('username'), decryption(ise_details.get('password')))
    ISE_NO = ise_details.get('serial_no') + "/"
    ARRAYS = https_str + "://" + str(IP) + "/storage/arrays/"
    
    return (ARRAYS+ISE_NO, AUTH, ise_id)
    
    # mrc1_ping_response = subprocess.Popen(['ping', str(ise_details[0]['ip_primary']), '-c', '2', "-W", "2"],
    #                                       shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # mrc1_ping_response.wait()
    # # mrc1_ping_response = os.system("ping -c 1 " + str(ise_details[0]['ip_primary']))
    # if mrc1_ping_response.poll() == 0:
    #     ARRAYS = https_str + "://" + ise_details[0]['ip_primary'] + "/storage/arrays/"
    #     return (ARRAYS+ISE_NO, AUTH, ise_id)

    # mrc2_ping_response = subprocess.Popen(['ping', str(ise_details[0]['ip_secondary']), '-c', '2', "-W", "2"],
    #                                       shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # mrc2_ping_response.wait()
    # # mrc2_ping_response = os.system("ping -c 1 " + str(ise_details[0]['ip_secondary']))
    # if mrc2_ping_response.poll() == 0:
    #     ARRAYS = https_str + "://" + ise_details[0]['ip_secondary'] + "/storage/arrays/"
    #     return (ARRAYS+ISE_NO, AUTH, ise_id)

    # return status.HTTP_504_GATEWAY_TIMEOUT


def get_valid_ip(ise_id, https=True):

    IP = None
    ise_details = {}

    try:
        ise_details = ListIse.objects.values('id','ip_primary', 'mrc1_status',
                                         'mrc2_status', 'ip_secondary',
                                         'serial_no', 'username',
                                         'password').get(id=ise_id)
    except:
        pass

    if not ise_details:
      return status.HTTP_404_NOT_FOUND

    https_str = 'http' if not https else 'https'
      

    if ise_details.get('mrc1_status'):
        IP = ise_details.get('ip_primary')
    elif ise_details.get('mrc2_status'):
        IP = ise_details.get('ip_secondary')
    else:
        return status.HTTP_504_GATEWAY_TIMEOUT


    AUTH = (ise_details.get('username'), decryption(ise_details.get('password')))
    ISE_NO = ise_details.get('serial_no') + "/"
    ARRAYS = https_str + "://" + str(IP) + "/query/"
    
    return (ARRAYS, AUTH, ise_id)

if __name__ == '__main__':
    print dynamic_url(1)