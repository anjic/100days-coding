from Crypto.Cipher import AES
import base64
import os
from config import encryption_key

def encryption(data):

	BLOCK_SIZE = 16
	PADDING = '{'
	pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
	EncodeAES = lambda c,s: base64.b64encode(c.encrypt(pad(s)))
	cipher = AES.new(encryption_key)
	return EncodeAES(cipher, data)


def decryption(data):

	PADDING = '{'
	DecodeAES = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING)
	cipher = AES.new(encryption_key)
	return DecodeAES(cipher, data)


if __name__ == '__main__':
	
	print encryption('hello'),type(encryption('hello'))
	# print decryption('ThZEbDg6OSpznDBPYY73BA=='),type(decryption('ThZEbDg6OSpznDBPYY73BA=='))