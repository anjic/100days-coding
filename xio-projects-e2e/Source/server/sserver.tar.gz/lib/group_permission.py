from functools import wraps
from rest_framework import status
from rest_framework.response import Response
import jwt

from django.contrib.auth.models import (User, Group)
from config import secret


def User_Permision(permission):
    def decorator(func):
        def inner_decorator(request, *args, **kwargs):
            if 'HTTP_AUTHORIZATION' in args[0].META:
                permission_list = Permission_list(args[0].META['HTTP_AUTHORIZATION'])
                if permission in permission_list:
                    return func(request, *args, **kwargs)
                else:
                    # print 'Forbidden.You dont have permission to view %s!'%permission
                    return Response('Permission Denied', status=status.HTTP_401_UNAUTHORIZED)
            else:
                return Response('Authorization Token Missing', status=status.HTTP_401_UNAUTHORIZED)
        return wraps(func)(inner_decorator)
    return decorator


def Permission_list(token):
    group_permission = []
    user = jwt.decode(token[4:], secret, algorithm='HS256')
    groups = User.objects.values('groups').filter(username=user['username'])
    permission_list = Group.objects.get(id=groups[0]['groups']).permissions.values('codename')
    for permission in permission_list:
        group_permission.append(permission['codename'])
    return group_permission
