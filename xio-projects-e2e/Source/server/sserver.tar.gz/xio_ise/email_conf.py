import ConfigParser
from xio_ise.local_settings import CONF_DIR
from api.models.settings import SMTPConfig
from utility.encryption import encryption, decryption

class EmailConfig():
	"""docString for EmailConfig"""

	def get_object(self, id):
		"""To get particular User object"""
		try:
			return SMTPConfig.objects.get(id=id)
		except SMTPConfig.DoesNotExist:
			return None

	def __init__(self):

		config = ConfigParser.RawConfigParser()
		config.read(CONF_DIR + 'schedule.cfg')

		try:
			smtp =  dict(config.items('smtp'))
		except:
			config.add_section('smtp')

		smtp = self.get_object(id=1)
		if smtp:
			self.EMAIL_HOST = smtp.email_host
			self.EMAIL_HOST_USER = smtp.email_host_user
			self.EMAIL_HOST_PASSWORD = decryption(smtp.email_host_password)
			self.EMAIL_PORT = smtp.email_port
			self.FROM_MAIL = smtp.from_mail
			self.ENABLE_AUTHENTICATION = smtp.enable_authentication
			self.USE_SSL_TL = smtp.use_ssl_tl
		else:
			self.EMAIL_HOST = None
			self.EMAIL_HOST_USER = None
			self.EMAIL_HOST_PASSWORD = None
			self.EMAIL_PORT = None
			self.FROM_MAIL = None
			self.ENABLE_AUTHENTICATION = None
			self.USE_SSL_TL = None

if __name__ == '__main__':
	email = EmailConfig()
	print email.EMAIL_HOST
